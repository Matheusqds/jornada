/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aula.pkg2.bimestre;

/**
 *
 * @author matheus.qsouza
 */
public class Aula2Bimestre {
    public static void frase(){
        System.out.println("Imprimindo uma funçao");
    }
    public static void flor(){ 
        System.out.println("rosa");         
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        frase();
        flor();
        frase();

    }
    
}
